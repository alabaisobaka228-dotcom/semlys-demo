(() => {
  const key = 'semlys-visual-v2';
  const store = semlysHistory.open(key);
  let saved = {};
  try { saved = store.read().current; } catch {}
  const textTargets = '.hero h2,.hero p,.hero-meta span,.section-heading h2,.info-copy h2,[data-store],.catalog-title,.demo-product h3,.demo-product p,.catalog-filter summary';
  const fields = [...document.querySelectorAll(textTargets)].map((node, index) => {
    const card = node.closest('[data-item-id]');
    const field = card ? 'item:' + card.dataset.itemId + ':' + [...card.children].indexOf(node)
      : 'text:' + location.pathname + ':' + index;
    return [field, node];
  });
  const photos = [...document.querySelectorAll('.demo-product .product-image,#store-image')].map(node => [
    node.id ? 'store-photo' : 'photo:' + node.closest('button').dataset.itemId, node
  ]);
  function showPhoto(node, source) {
    let image = node.querySelector('.visual-photo');
    if (!image) {
      image = new Image();
      image.className = 'visual-photo';
      image.alt = '';
      node.append(image);
    }
    image.src = source;
  }
  const storeSettingsKey = 'semlys-store-settings';
  function applyLegacyStoreFields() {
    try {
      if (localStorage.getItem(storeSettingsKey) !== null) return;
    } catch { return; }
    for (const [name, node] of fields) {
      if (node.hasAttribute('data-store') && typeof saved[name] === 'string') node.textContent = saved[name];
    }
    for (const [name, node] of photos) {
      if (node.id === 'store-image' && saved[name]) showPhoto(node, saved[name]);
    }
  }
  applyLegacyStoreFields();
  addEventListener('pageshow', applyLegacyStoreFields);
  for (const [name, node] of fields) {
    if (!node.hasAttribute('data-store') && typeof saved[name] === 'string') node.textContent = saved[name];
  }
  for (const [name, node] of photos) {
    if (node.id !== 'store-image' && saved[name]) showPhoto(node, saved[name]);
  }
  addEventListener('storage', event => {
    if (event.key === storeSettingsKey) document.querySelector('#store-image .visual-photo')?.remove();
    if (event.key === key && !new URLSearchParams(location.search).has('edit')) location.reload();
  });
  if (new URLSearchParams(location.search).get('edit') !== '1') return;

  const bar = document.createElement('form');
  bar.className = 'visual-toolbar';
  bar.innerHTML = '<label>Демо-пароль <input type="password" required></label><button>Войти</button><output role="status"></output>';
  document.body.prepend(bar);
  bar.onsubmit = event => {
    event.preventDefault();
    if (bar.querySelector('input').value !== 'SEMLYS-demo') {
      bar.querySelector('output').textContent = 'Неверный пароль.';
      return;
    }
    bar.onsubmit = event => event.preventDefault();
    bar.innerHTML = '<strong>Редактирование SEMLYS</strong><button type="button">Сохранить изменения</button><a>К витрине</a><a href="admin.html">Настройки магазина</a><details><summary>История сохранений</summary></details><output role="status"></output>';
    const view = new URL(location.href);
    view.searchParams.delete('edit');
    bar.querySelector('a').href = view.href;
    const status = bar.querySelector('output');
    const save = bar.querySelector('button');
    const pending = new Set();
    const entrance = document.querySelector('#store-image');
    if (entrance) {
      const photoStore = semlysHistory.open(storeSettingsKey);
      const label = document.createElement('label');
      label.className = 'visual-picker';
      label.textContent = 'Фото входа ';
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/jpeg,image/png,image/webp';
      label.append(input);
      const savePhoto = document.createElement('button');
      savePhoto.type = 'button';
      savePhoto.textContent = 'Сохранить фото входа';
      savePhoto.disabled = true;
      const controls = document.createElement('div');
      const photoStatus = document.createElement('output');
      photoStatus.setAttribute('role', 'status');
      controls.append(label, savePhoto, photoStatus);
      entrance.parentElement.after(controls);
      let photo;
      input.onchange = async () => {
        const file = input.files[0];
        savePhoto.disabled = true;
        photoStatus.textContent = '';
        if (!file) return;
        if (!/^image\/(jpeg|png|webp)$/.test(file.type) || file.size > 25 * 1024 * 1024) {
          photoStatus.textContent = 'Выбери JPEG, PNG или WebP до 25 МБ.';
          return;
        }
        try {
          const bitmap = await createImageBitmap(file);
          const canvas = document.createElement('canvas');
          try {
            const scale = Math.min(1, 1400 / Math.max(bitmap.width, bitmap.height));
            canvas.width = Math.max(1, Math.round(bitmap.width * scale));
            canvas.height = Math.max(1, Math.round(bitmap.height * scale));
            const context = canvas.getContext('2d', {alpha: false});
            context.fillStyle = '#fff';
            context.fillRect(0, 0, canvas.width, canvas.height);
            context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
          } finally {
            bitmap.close();
          }
          if (input.files[0] !== file) return;
          photo = canvas.toDataURL('image/jpeg', 0.82);
          showPhoto(entrance, photo);
          savePhoto.disabled = false;
          photoStatus.textContent = 'Фото готово к сохранению.';
        } catch {
          if (input.files[0] === file) photoStatus.textContent = 'Не удалось открыть фото.';
        }
      };
      savePhoto.onclick = () => {
        try {
          photoStore.save(current => ({...current, photo}));
          entrance.querySelector('.visual-photo')?.remove();
          dispatchEvent(new Event('semlys-store-photo-saved'));
          savePhoto.disabled = true;
          photoStatus.textContent = 'Фото входа сохранено.';
        } catch {
          photoStatus.textContent = 'Не удалось сохранить фото. Попробуй файл меньшего размера.';
        }
      };
    }
    const refreshHistory = semlysHistory.mount(
      bar.querySelector('details'), store, status, () => location.reload()
    );
    const draft = {};
    for (const [name, node] of fields) {
      if (node.hasAttribute('data-store')) continue;
      node.contentEditable = 'plaintext-only';
      node.classList.add('visual-editable');
      node.onclick = event => { event.preventDefault(); event.stopPropagation(); node.focus(); };
      node.oninput = () => { draft[name] = node.textContent; };
    }
    for (const [name, node] of photos) {
      if (node.id === 'store-image') continue;
      node.classList.add('visual-upload');
      const label = document.createElement('label');
      label.textContent = 'Загрузить фото';
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/jpeg,image/png,image/webp';
      label.append(input);
      const card = node.closest('.demo-product');
      if (card) {
        const slot = document.createElement('div');
        slot.className = 'visual-card-slot';
        card.before(slot);
        slot.append(card, label);
      } else {
        node.after(label);
      }
      label.className = 'visual-picker';
      label.onclick = event => event.stopPropagation();
      input.onchange = async () => {
        pending.delete(input);
        save.disabled = pending.size > 0;
        const file = input.files[0];
        if (!file) return;
        if (!/^image\/(jpeg|png|webp)$/.test(file.type) || file.size > 2 * 1024 * 1024) {
          status.textContent = 'Выбери JPEG, PNG или WebP до 2 МБ.';
          return;
        }
        const reader = new FileReader();
        pending.add(input);
        save.disabled = true;
        reader.onload = () => {
          if (input.files[0] !== file) return;
          pending.delete(input);
          save.disabled = pending.size > 0;
          draft[name] = reader.result;
          showPhoto(node, reader.result);
          status.textContent = 'Фото добавлено. Нажми «Сохранить».';
        };
        reader.onerror = () => {
          if (input.files[0] !== file) return;
          pending.delete(input);
          save.disabled = pending.size > 0;
          status.textContent = 'Не удалось прочитать фото.';
        };
        reader.readAsDataURL(file);
      };
    }
    save.onclick = () => {
      try {
        store.save(current => ({...current, ...draft}));
        Object.keys(draft).forEach(name => delete draft[name]);
        refreshHistory();
        status.textContent = 'Сохранено в этом браузере.';
      } catch {
        status.textContent = 'Не удалось сохранить. Попробуй фото меньшего размера.';
      }
    };
  };
  document.querySelectorAll('a[href]').forEach(link => {
    const href = link.getAttribute('href');
    if (!href || !/^(index|products)\.html(?:[?#]|$)/.test(href)) return;
    const url = new URL(href, location.href);
    url.searchParams.set('edit', '1');
    link.href = url.href;
  });
})();
